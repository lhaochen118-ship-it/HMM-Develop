| held-out | chosen on the others | held-out err | recall | segFAR | best label-free on held-out | regret (m) |
|---|---|---|---|---|---|---|
| 4s:countryside | CMS-CPC/H+SH+G(a=0.01) | 44.0 | 0.397 | 0.001 | CMS-CPC/H+SH+G(a=0.01) (44.0) | 0.0 |
| 4s:office_loop | CMS-CPC/H+SH+G(a=0.01) | 10.6 | 0.730 | 0.000 | CMS-CPC/H+SH(a=0.01) (10.5) | 0.1 |
| 4s:old_town | CMS-CPC/H+SH+G(a=0.01) | 27.5 | 0.695 | 0.006 | CMS-CPC/H+SH+G(a=0.01) (27.5) | 0.0 |
| boreas | CMS-CPC/H+SH+G(a=0.01) | 5.7 | 0.747 | 0.002 | CMS-F+SH(a=0.01) (4.0) | 1.8 |
| cmu | CMS-CPC/H+SH+G(a=0.01) | 4.1 | 0.787 | 0.010 | CMS-F+SH(a=0.01) (3.5) | 0.6 |
| nclt | CMS-CPC/H+SH+G(a=0.01) | 4.6 | 0.582 | 0.001 | CPC-SC+CS(alpha=0.01) (4.1) | 0.5 |
| nord | CMS-CPC/H+SH+G(a=0.01) | 7.5 | 0.696 | 0.002 | CMS-CPC/H+SH+G(a=0.01) (7.5) | 0.0 |
