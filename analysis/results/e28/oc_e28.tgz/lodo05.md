| held-out | chosen on the others | held-out err | recall | segFAR | best label-free on held-out | regret (m) |
|---|---|---|---|---|---|---|
| 4s:countryside | CPC-SC-T0.5+CS | 52.9 | 0.320 | 0.000 | CMS-CPC/H+SH+G (33.7) | 19.2 |
| 4s:office_loop | CPC-SC-T0.5+CS | 11.7 | 0.718 | 0.000 | CMS-U/H+SH (9.8) | 2.0 |
| 4s:old_town | CPC-SC-T0.5+CS | 30.5 | 0.613 | 0.001 | CMS-CPC/H+SH+G (26.8) | 3.6 |
| boreas | CPC-SC-T0.5+CS | 5.1 | 0.662 | 0.001 | CMS-F+SH (4.5) | 0.6 |
| cmu | CPC-SC-T0.5+CS | 4.3 | 0.762 | 0.004 | CPC-SC+CS (3.8) | 0.5 |
| nclt | CMS-F+SH | 7.8 | 0.512 | 0.004 | certified (3.7) | 4.1 |
| nord | CPC-SC+CS | 9.6 | 0.644 | 0.000 | CMS-CPC/H+SH+G (7.3) | 2.3 |
