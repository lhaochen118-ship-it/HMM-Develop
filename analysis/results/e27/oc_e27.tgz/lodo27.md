| held-out | chosen on the others | held-out err | recall | segFAR | best label-free on held-out | regret (m) |
|---|---|---|---|---|---|---|
| 4s:countryside | CPC-W+CS+SH | 54.5 | 0.276 | 0.000 | CPC-SC-T+SH (51.0) | 3.5 |
| 4s:office_loop | CPC-W+CS+SH | 11.6 | 0.692 | 0.000 | CPC-SC+SH (11.3) | 0.3 |
| 4s:old_town | CPC-W+CS+SH | 32.7 | 0.586 | 0.000 | CPC-SC-T+SH (29.7) | 2.9 |
| boreas | CPC-W+CS+SH | 5.3 | 0.655 | 0.001 | CPC-SC-Tmin+CS (5.0) | 0.3 |
| cmu | CPC-SC-T0.5+CS | 4.3 | 0.762 | 0.004 | CPC-SC-Tmin+CS (3.5) | 0.8 |
| nclt | CPC-SC-T+CS | 4.6 | 0.552 | 0.000 | TCEmin (3.7) | 1.0 |
| nord | CPC-W+CS+SH | 9.2 | 0.650 | 0.000 | CPC-W+CS+SH (9.2) | 0.0 |
